class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
        }
        footer {
          background: #1e3a8a;
          color: white;
          padding: 3rem 0 1rem;
        }
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
        }
        .footer-content {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
          margin-bottom: 2rem;
        }
        .footer-column h3 {
          font-size: 1.25rem;
          margin-bottom: 1rem;
          color: #f97316;
        }
        .footer-column ul {
          list-style: none;
          padding: 0;
        }
        .footer-column ul li {
          margin-bottom: 0.5rem;
        }
        .footer-column ul li a {
          color: #cbd5e1;
          text-decoration: none;
          transition: color 0.3s;
        }
        .footer-column ul li a:hover {
          color: white;
        }
        .social-links {
          display: flex;
          gap: 1rem;
          margin-top: 1rem;
        }
        .social-links a {
          display: inline-block;
          width: 40px;
          height: 40px;
          background: rgba(255,255,255,0.1);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.3s;
        }
        .social-links a:hover {
          background: #f97316;
        }
        .copyright {
          border-top: 1px solid rgba(255,255,255,0.1);
          padding-top: 1rem;
          text-align: center;
          color: #94a3b8;
          font-size: 0.875rem;
        }
      </style>
      <footer>
        <div class="container">
          <div class="footer-content">
            <div class="footer-column">
              <h3>MediScript Pro</h3>
              <p>Professional medical research writing services for students, researchers, and healthcare professionals worldwide.</p>
              <div class="social-links">
                <a href="#" aria-label="Facebook">f</a>
                <a href="#" aria-label="Twitter">t</a>
                <a href="#" aria-label="LinkedIn">in</a>
                <a href="#" aria-label="Instagram">ig</a>
              </div>
            </div>
            
            <div class="footer-column">
              <h3>Services</h3>
              <ul>
                <li><a href="#">Thesis Writing</a></li>
                <li><a href="#">Dissertation Writing</a></li>
                <li><a href="#">Synopsis Creation</a></li>
                <li><a href="#">Review Papers</a></li>
                <li><a href="#">Research Papers</a></li>
                <li><a href="#">Plagiarism Removal</a></li>
              </ul>
            </div>
            
            <div class="footer-column">
              <h3>Company</h3>
              <ul>
                <li><a href="/about.html">About Us</a></li>
                <li><a href="/how-it-works.html">How It Works</a></li>
                <li><a href="/pricing.html">Pricing</a></li>
                <li><a href="/blog.html">Blog</a></li>
                <li><a href="/contact.html">Contact</a></li>
                <li><a href="/faq.html">FAQ</a></li>
              </ul>
            </div>
            
            <div class="footer-column">
              <h3>Contact Info</h3>
              <ul>
                <li>Email: contact@mediscriptpro.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Address: 123 Medical Plaza, Suite 100</li>
                <li>Healthcare District, CA 90210</li>
              </ul>
            </div>
          </div>
          
          <div class="copyright">
            <p>&copy; 2023 MediScript Pro. All rights reserved. | <a href="/privacy.html">Privacy Policy</a> | <a href="/terms.html">Terms of Service</a></p>
          </div>
        </div>
      </footer>
    `;
  }
}

customElements.define('custom-footer', CustomFooter);