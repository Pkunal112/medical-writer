class CustomHeader extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
        }
        header {
          background: white;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 50;
        }
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          height: 70px;
        }
        .logo {
          font-size: 1.5rem;
          font-weight: 700;
          color: #1e3a8a;
          text-decoration: none;
          display: flex;
          align-items: center;
        }
        .logo-icon {
          margin-right: 0.5rem;
          color: #f97316;
        }
        nav ul {
          display: flex;
          list-style: none;
        }
        nav li {
          margin: 0 1rem;
        }
        nav a {
          text-decoration: none;
          color: #374151;
          font-weight: 500;
          transition: color 0.3s;
        }
        nav a:hover {
          color: #1e3a8a;
        }
        .cta-button {
          background: #f97316;
          color: white;
          padding: 0.5rem 1.5rem;
          border-radius: 0.5rem;
          font-weight: 600;
          text-decoration: none;
          transition: background 0.3s;
        }
        .cta-button:hover {
          background: #ea580c;
        }
        .mobile-menu-button {
          display: none;
          background: none;
          border: none;
          font-size: 1.5rem;
          cursor: pointer;
          color: #374151;
        }
        @media (max-width: 768px) {
          .nav-menu {
            display: none;
            position: absolute;
            top: 70px;
            left: 0;
            right: 0;
            background: white;
            flex-direction: column;
            padding: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          .nav-menu.active {
            display: flex;
          }
          nav ul {
            flex-direction: column;
          }
          nav li {
            margin: 0.5rem 0;
          }
          .mobile-menu-button {
            display: block;
          }
        }
      </style>
      <header>
        <div class="container">
          <a href="/" class="logo">
            <span class="logo-icon">📝</span>
            MediScript Pro
          </a>
          
          <button class="mobile-menu-button" id="menuButton">☰</button>
          
          <nav class="nav-menu" id="navMenu">
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/services.html">Services</a></li>
              <li><a href="/about.html">About</a></li>
              <li><a href="/how-it-works.html">How It Works</a></li>
              <li><a href="/contact.html">Contact</a></li>
              <li><a href="/blog.html">Blog</a></li>
              <li><a href="/pricing.html" class="cta-button">Get Quote</a></li>
            </ul>
          </nav>
        </div>
      </header>
    `;

    const menuButton = this.shadowRoot.getElementById('menuButton');
    const navMenu = this.shadowRoot.getElementById('navMenu');
    
    menuButton.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }
}

customElements.define('custom-header', CustomHeader);